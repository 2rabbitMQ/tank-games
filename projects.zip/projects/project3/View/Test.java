package projects.project3.View;

import projects.project3.java.TankGame;

public class Test {
    public static void main(String[] args) {
        new TankGame();
    }
}
