package projects.project3.View;

import projects.project3.java.TankGame;

  public  class Main{
    public static void main(String[] args) {

        new Start();
   }

}