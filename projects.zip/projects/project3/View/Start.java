package projects.project3.View;
import projects.project3.java.TankGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Start extends  JFrame{
    private  JButton start=new JButton("开始新游戏");
    private JButton con=new JButton("继续上局游戏");
    ImageIcon imageIcon=new ImageIcon("D:\\GamePhotosMaterials\\start.jpg");
    JLabel jl=new JLabel();
    public Start(){
        init();
        addComponent();
        addListener();
    }
    public void init(){
        setTitle("坦克小游戏");
        setLayout(null);
        setSize(600,420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
    public void addComponent(){
        jl.setIcon(imageIcon);
        jl.setBounds(0,0,600,420);
        Font font=new Font("楷体",Font.BOLD,12);
        start.setFont(font);
        con.setFont(font);
        start.setBounds(230,160,115,40);
        con.setBounds(230,220,115,40);
        this.add(start);
        this.add(con);
        this.add(jl);
    }

    public void addListener(){
        start.addActionListener(new ActionListener() {//添加开始游戏按钮的监听事件
            @Override
            public void actionPerformed(ActionEvent e) {
                new TankGame();
//                new TankGame();
            }
        });
        con.addActionListener(new ActionListener() {//添加继续上局游戏的监听事件
            @Override
            public void actionPerformed(ActionEvent e) {
                //dispose();//关闭当前窗口


            }

        });
    }

}