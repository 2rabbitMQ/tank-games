package projects.project3.java;

import java.awt.*;

public class Bomb  extends GameObject{
    static Image[] imgs=new Image[8];
    int explodeCount=0;
    static{
        for (int i = 0; i < 8; i++) {
       imgs[i]=Toolkit.getDefaultToolkit().getImage("D://GamePhotosMaterials//"+(i+1)+".gif");

        }

    }
    public Bomb(String img, int x, int y, TankGame tankGame) {
        super(img, x, y, tankGame);
    }

    @Override
    public void paintSelf(Graphics g) {

        while(explodeCount<16){
          g.drawImage(imgs[(explodeCount++)/2], x, y, null);
      }
    }

    @Override
    public Rectangle getRec() {
        return null;
    }
    }
