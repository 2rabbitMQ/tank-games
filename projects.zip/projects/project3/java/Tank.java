package projects.project3.java;

import java.awt.*;
import java.util.ArrayList;

public abstract class Tank extends GameObject{
    public int width=48;
    public int height=48;
    public  int speed=3;
    public Direction direction=Direction.UP;
    public String upImg;
    public String leftImg;
    public String rightImg;
    public String downImg;
    public int bloodx;
    public int bloody;
    public int bloodwidth;
    public int bloodheight;
    public boolean isFirst=true;
    public boolean alive=false;
    private boolean attackCoolDown=true;//攻击冷却状态
    private int attackCoolDownTime=1000;//冷却间隔时间
    public Tank(String img,int x,int y,TankGame tankGame,String upImg,String leftImg,String rightImg,String downImg){
        super(img,x,y,tankGame);
        this.upImg=upImg;
        this.leftImg=leftImg;
        this.rightImg=rightImg;
        this.downImg=downImg;
        switch(direction){
            case UP:bloodx=x;bloody=y-10;break;
            case LEFT:bloodx=x-10;bloody=y+60;break;
            case RIGHT:bloodx=x+50;bloody=y;break;
            case DOWN:bloodx=x;bloody=y+50;break;
        }
        bloodwidth=50;
        bloodheight=10;
        isFirst=false;
    }
    public boolean hitWall(int x,int y){
        ArrayList<Wall> walls=this.tankGame.walls;
        Rectangle next=new Rectangle(x,y,width,height);
        for (Wall wall:walls) {
            if(next.intersects(wall.getRec()))
                return true;
        }
    return false;
    }
    public boolean hitWhiteWall(int x,int y){
        ArrayList<WhiteWall> whiteWalls=this.tankGame.whiteWalls;
        Rectangle next=new Rectangle(x,y,width,height);
        for (WhiteWall whitewall:whiteWalls) {
            if(whitewall.getRec().intersects(next)) return true;
        }
        return false;
    }
    public boolean moveBorder(int x,int y){
      if(x<0||x+width>this.tankGame.getWidth()||
      y<30||y+height>this.tankGame.getHeight())
          return true;
      return false;
    }
    public void addblood(){
       ArrayList<Love> loves=this.tankGame.loves;
       Rectangle coord=new Rectangle(x,y,width,height);
        for (Love love:loves) {
          if(love.getRec().intersects(coord)&&bloodwidth!=50){
             bloodwidth+=20;
            this.tankGame.loves.remove(love);
          }
        }
    }
    public void downblood(){
       ArrayList<Bombs> bom=this.tankGame.Bomb;
       Rectangle coord=new Rectangle(x,y,width,height);
        for (Bombs bomm:bom) {
            if(bomm.getRec().intersects(coord)){
                bloodwidth-=20;
               this.tankGame.Bomb.remove(bomm);
            }
        }

    }
    public abstract void paintSelf(Graphics g);
    public abstract Rectangle getRec();
    public void leftward(){
        direction=Direction.LEFT;
        setImG(leftImg);
        if(!hitWall(x-speed,y)&&!moveBorder(x-speed,y)&&!hitWhiteWall(x-speed,y))
        x-=speed;
    }
    public void upward(){
        direction=Direction.UP;
        setImG(upImg);
        if(!hitWall(x,y-speed)&&!moveBorder(x,y-speed)&&!hitWhiteWall(x,y-speed))
            y-=speed;
    }
    public void rightward(){
        direction=Direction.RIGHT;
        setImG(rightImg);
        if(!hitWall(x+speed,y)&&!moveBorder(x+speed,y)&&!hitWhiteWall(x+speed,y))
            x+=speed;
    }
    public void downward(){
        direction=Direction.DOWN;
        setImG(downImg);
        if(!hitWall(x,y+speed)&&!moveBorder(x,y+speed)&&!hitWhiteWall(x,y+speed))
            y+=speed;
    }
    public void SetBloodCoord(){
        if(!isFirst){
          switch(direction){
              case UP:bloodx=x;bloody=y-10;break;
              case LEFT:bloodx=x-10;bloody=y;break;
              case RIGHT:bloodx=x+50;bloody=y;break;
              case DOWN:bloodx=x;bloody=y+50;break;
          }

      }

    }


  public void setImG(String img){
        image=Toolkit.getDefaultToolkit().getImage(img);
    }
  public void attack(){
      String s="D:\\GamePhotosMaterials\\bullet.png";
      Bullet bullet=null;
      if(attackCoolDown&&alive){
       switch(direction){
            case LEFT:bullet=new Bullet(s,x,y+height/2-5,this.tankGame,this.direction);break;
            case UP:bullet=new Bullet(s,x+width/2-5,y,this.tankGame,this.direction);break;
            case RIGHT:bullet=new Bullet(s,x+width,y+height/2-5,this.tankGame,this.direction);break;
            case DOWN:bullet=new Bullet(s,x+width/2-5,y+height,this.tankGame,this.direction);break;
        }
      this.tankGame.bullets.add(bullet);
      new AttackCD().start();
      }

  }
  class AttackCD extends Thread{
      @Override
      public void run() {
          attackCoolDown=false;
          try {
              Thread.sleep(attackCoolDownTime);
          } catch (InterruptedException e) {
              e.printStackTrace();
          }finally {
              attackCoolDown=true;
              this.stop();
          }
      }
  }
}
