package projects.project3.java;

import java.awt.*;

public class Grass extends GameObject{
    int length=50;
    public Grass(String img, int x, int y, TankGame tankGame) {
        super(img, x, y, tankGame);
    }

    @Override
    public void paintSelf(Graphics g) {
      g.drawImage(image,x,y,null);
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,length,length);
    }
}
