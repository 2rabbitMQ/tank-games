package projects.project3.java;

import java.awt.*;
import java.util.Random;

public class Enemy  extends Tank{
    int height2=50;
    public Enemy(String img, int x, int y, TankGame tankGame, String upImg, String leftImg, String rightImg, String downImg) {
        super(img, x, y, tankGame, upImg, leftImg, rightImg, downImg);
    }
    int movetime;
    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(image,x,y,null);
        drawblood(g);
        move();
        addblood();
        downblood();
    }
    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,width,height);
    }
    public Direction randomDirection(){
        Random random=new Random();
        int num=random.nextInt(4);
        switch(num){
            case 0:return Direction.LEFT;
            case 1:return Direction.RIGHT;
            case 2:return Direction.UP;
            case 3:return Direction.DOWN;
            default:return null;
        }
    }
    public void  drawblood(Graphics g){
        int width=bloodwidth;int height=bloodheight;int t;
        SetBloodCoord();
        g.setColor(Color.white);
        g.setColor(Color.RED);
        switch (direction){
            case LEFT:case RIGHT:t=width;width=height;height=t;break;
            default:break;
        }
        g.fillRect(bloodx,bloody,width,height);
    }
    public void move(){
       attack();
      if(movetime>=20){
          direction=randomDirection();
          movetime=0;
      }
      else movetime+=1;
      switch(direction) {
          case  UP:upward();break;
          case LEFT:leftward();break;
          case DOWN:downward();break;
          case RIGHT:rightward();break;
      }

    }
    public void attack(){
     Random random=new Random();
     int num=random.nextInt(400);
     if(num<4) {
         EnemyBullet enemyBullet = null;
         String s = "D:\\GamePhotosMaterials\\enemybullet.png";
         switch (direction) {
             case LEFT:
                 enemyBullet = new EnemyBullet(s, x, y + height / 2 - 5, this.tankGame, this.direction);
                 break;
             case UP:
                 enemyBullet = new EnemyBullet(s, x + width / 2 - 5, y, this.tankGame, this.direction);
                 break;
             case RIGHT:
                 enemyBullet = new EnemyBullet(s, x + width, y + height / 2 - 5, this.tankGame, this.direction);
                 break;
             case DOWN:
                 enemyBullet = new EnemyBullet(s, x + width / 2 - 5, y + height, this.tankGame, this.direction);
                 break;
         }
         this.tankGame.enemyBullets.add(enemyBullet);
     }

    }

}
