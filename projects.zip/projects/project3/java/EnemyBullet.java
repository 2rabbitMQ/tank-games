package projects.project3.java;

import java.awt.*;
import java.util.ArrayList;

public class EnemyBullet  extends Bullet{
   public int width=10;
   public  int height=10;
    public EnemyBullet(String img, int x, int y, TankGame tankGame, Direction direction) {
        super(img, x, y, tankGame, direction);
    }
    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(image,x,y,null);
        this.Bulletmove();
        this.hitPlayer();
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,width,height);
    }
    public void hitPlayer(){
        ArrayList<Tank> players=this.tankGame.playerList;
        for (Tank player:players) {
            if(this.getRec().intersects(player.getRec())) {//判断两个矩形是否相交
                player.bloodwidth-=20;
                if(player.bloodwidth<=0){
                 this.tankGame.bombs.add(new Bomb("",player.x-34,player.y-14,this.tankGame));
                 this.tankGame.playerList.remove(player);
                 player.alive=false;
                }
                this.tankGame.removeList.add(this);
                break;
            }
        }
    }

}
