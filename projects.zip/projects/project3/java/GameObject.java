package projects.project3.java;

import java.awt.*;

public abstract class GameObject {
    public Image image;
    public int x;
    public int y;
    public static TankGame tankGame;
    public GameObject (String img,int x,int y,TankGame tankGame){
        this.image=Toolkit.getDefaultToolkit().getImage(img);
        this.x=x;
        this.y=y;
        this.tankGame=tankGame;
    }
    public abstract void paintSelf(Graphics g);
    public abstract Rectangle getRec();


}
