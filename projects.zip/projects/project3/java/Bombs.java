package projects.project3.java;

import java.awt.*;

public class Bombs extends  GameObject{
    int length=40;
    public Bombs(String img, int x, int y, TankGame tankGame) {
        super(img, x, y, tankGame);
    }
    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(image,x,y,null);
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,length,length);
    }
}
