package projects.project3.java;

import java.awt.*;
import java.util.ArrayList;

public class Bullet extends GameObject {
    int width=10;
    int height=10;
    int speed=7;
    Direction direction;
    public Bullet(String img, int x, int y, TankGame tankGame,Direction direction) {
        super(img, x, y, tankGame);
        this.direction=direction;
    }
    public void leftward(){
        x-=speed;
    }
    public void rightward(){
        x+=speed;
    }

    public void upward(){
        y-=speed;
    }
    public void downward(){
        y+=speed;
    }
    public void Bulletmove(){
        switch(direction){
            case LEFT:leftward();break;
            case RIGHT:rightward();break;
            case UP:upward();break;
            case DOWN:downward();break;
        }
        this.hitWall();
        this.hitBase();
        this.hitGrass();
        this.hitWhiteWall();
    }

    @Override
    public void paintSelf(Graphics g) {
    g.drawImage(image,x,y,null);
    this.Bulletmove();
    this.hitEnemy();
    }

    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,width,height);
    }
    public void hitEnemy(){
        ArrayList<Enemy> enemies=this.tankGame.enemies;
        for (Enemy enemy:enemies) {
         if(this.getRec().intersects(enemy.getRec())) {//判断两个矩形是否相交
             enemy.bloodwidth-=20;
             if(enemy.bloodwidth<=0){
             this.tankGame.enemies.remove(enemy);
             this.tankGame.bombs.add(new Bomb("",enemy.x-34,enemy.y-14,this.tankGame));
             }
             this.tankGame.removeList.add(this);
             break;
         }
        }
    }

    public void hitWall(){
    ArrayList<Wall> walls=this.tankGame.walls;
        for (Wall wall:walls) {
          if(this.getRec().intersects(wall.getRec())){
              this.tankGame.walls.remove(wall);
              this.tankGame.removeList.add(this);
              break;
          }

        }
    }
    public void hitBase(){
        ArrayList<Base> bases=this.tankGame.bases;
        for (Base base:bases) {
            if(this.getRec().intersects(base.getRec())){
                if(this instanceof EnemyBullet)
                this.tankGame.bases.remove(base);
                this.tankGame.removeList.add(this);
                break;
            }
        }
    }
    public void hitGrass(){
        ArrayList<Grass> grasses=this.tankGame.grasses;
        for (Grass grass:grasses) {
            if(this.getRec().intersects(grass.getRec())){
                this.tankGame.removeList.add(this);
                break;
            }
        }
    }
    public void hitWhiteWall(){
        ArrayList<WhiteWall> whiteWalls=this.tankGame.whiteWalls;
        for (WhiteWall whiteWall:whiteWalls) {
            if(this.getRec().intersects(whiteWall.getRec())){
                this.tankGame.removeList.add(this);
                break;
            }
        }
    }


    public void moveBorder(){
     if(x<0||x+width>this.tankGame.getWidth()||y<0||y+height>this.tankGame.getHeight()) {
     this.tankGame.removeList.add(this);
     }

    }
}
