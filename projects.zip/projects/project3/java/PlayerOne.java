package projects.project3.java;

import java.awt.*;
import java.awt.event.KeyEvent;

public class PlayerOne extends Tank {
    Boolean left=false;
    Boolean right=false;
    Boolean up=false;
    Boolean down=false;
    public PlayerOne(String img, int x, int y, TankGame tankGame, String upImg, String leftImg, String rightImg, String downImg) {
        super(img, x, y, tankGame, upImg, leftImg, rightImg, downImg);
    }


    @Override
    public void paintSelf(Graphics g) {
        g.drawImage(image,x,y,null);
        move();
        drawblood(g);
        addblood();
        downblood();
    }
public void move(){
      if(left) leftward();
        else if(right)  rightward();
               else if(up) upward();
                     else if(down) downward();

}

    public void  drawblood(Graphics g){
       int width=bloodwidth;int height=bloodheight;int t;
        SetBloodCoord();
        g.setColor(Color.white);
        g.setColor(Color.GREEN);
        switch (direction){
            case LEFT:case RIGHT:t=width;width=height;height=t;break;
            default:break;
        }
        g.fillRect(bloodx,bloody,width,height);
    }


     public void keyPressed(KeyEvent e){
        int key=e.getKeyCode();
         switch(key){
          case KeyEvent.VK_A:left=true;break;
          case KeyEvent.VK_S:down=true;break;
          case KeyEvent.VK_D:right=true;break;
          case KeyEvent.VK_W:up=true;break;
          case KeyEvent.VK_SPACE:attack();break;
     }
}
    public void keyReleased(KeyEvent e){
         int key=e.getKeyCode();
         switch(key){
          case KeyEvent.VK_A: case KeyEvent.VK_LEFT:left=false;break;
          case KeyEvent.VK_S: case KeyEvent.VK_DOWN:down=false;break;
          case KeyEvent.VK_D: case KeyEvent.VK_RIGHT:right=false;break;
          case KeyEvent.VK_W: case KeyEvent.VK_UP:up=false;break;
    }
}
    @Override
    public Rectangle getRec() {
        return new Rectangle(x,y,width,height);
    }

}
