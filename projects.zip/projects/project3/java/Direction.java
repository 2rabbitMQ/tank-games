package projects.project3.java;

public enum Direction {
UP,LEFT,RIGHT,DOWN
}
