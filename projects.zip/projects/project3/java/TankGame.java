package projects.project3.java;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Random;

public class TankGame extends JFrame {
    public int width = 800;
    public int height = 610;
    int y = 150;
    String s = "D://GamePhotosMaterials//";
    Image select = Toolkit.getDefaultToolkit().getImage(s + "MyTank-r.png");
    Image offScreemImage = null;
    int state = 0;//游戏模式 0 未开始 1 单人模式 2 双人模式
    int a;
    int count;
    int enemyCount = 0;
    ArrayList<Bullet> bullets = new ArrayList<>();
    ArrayList<Enemy> enemies = new ArrayList<>();
    ArrayList<EnemyBullet> enemyBullets = new ArrayList<>();
    ArrayList<Bullet> removeList = new ArrayList<>();
    ArrayList<Tank> playerList = new ArrayList<>();
    ArrayList<Wall> walls = new ArrayList<>();
    ArrayList<Base> bases = new ArrayList<>();
    ArrayList<Bomb> bombs = new ArrayList<>();
    ArrayList<Grass> grasses = new ArrayList<>();
    ArrayList<WhiteWall> whiteWalls = new ArrayList<>();
    ArrayList<Love> loves = new ArrayList<>();
    ArrayList<Bombs> Bomb = new ArrayList<>();
    PlayerOne playerOne = new PlayerOne(s + "MyTank-u.png", 125, 510, this, s + "MyTank-u.png", s + "MyTank-l.png", s + "MyTank-r.png", s + "MyTank-d.png");
    PlayerTwo playerTwo = new PlayerTwo(s + "myTank2-u.png", 460, 510, this, s + "myTank2-u.png", s + "myTank2-l.png", s + "myTank2-r.png", s + "myTank2-d.png");
    Enemy enemy = new Enemy(s + "EnemyTank-u.png", 500, 110, this, s + "EnemyTank-u.png", s + "EnemyTank-l.png", s + "EnemyTank-r.png", s + "EnemyTank-d.png");
    Base base1 = new Base(s + "base1.png", 350, 550, this);

    public TankGame() {

        init();
    }

    public void init() {
        //getContentPane().setBackground(Color.gray);
        setLayout(null);
        setTitle("超级无敌坦克小游戏");
        setSize(width, height);
        setLocationRelativeTo(null);//设置窗格居中
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setLayout(null);
        setVisible(true);
        this.addKeyListener(new TankGame.KeyMonitor());//添加键盘监视器
        addWall();
        addGrass();
        addwhiteWalls();
        addLove();
        addBomb();
        while (true) {//游戏规则
            if (enemies.size() == 0 && enemyCount == 10)
                state = 5;
            if ((state != 0) && (playerList.size() == 0 || bases.size() == 0)) {
                state = 4;
            }
            if (count % 100 == 1 && enemyCount < 10) {
                Random random = new Random();
                int rnum = random.nextInt(800);
                enemies.add(new Enemy(s + "EnemyTank-u.png", rnum, 110, this, s + "EnemyTank-u.png", s + "EnemyTank-l.png", s + "EnemyTank-r.png", s + "EnemyTank-d.png"));
                enemyCount += 1;
            }
            try {
                Thread.sleep(25);
                repaint();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        if (offScreemImage == null)
            offScreemImage = this.createImage(width, height);//创建和容器一样大小的图片
        Graphics gImage = offScreemImage.getGraphics();//获取该图片的画笔
        gImage.setColor(Color.white);
        gImage.fillRect(0, 0, width, height);
        gImage.setColor(Color.blue);
        gImage.setFont(new Font("仿宋", Font.BOLD, 50));
        if (state == 0) {
            gImage.drawString("" + "选择游戏模式", 220, 100);
            gImage.drawString("单人模式", 220, 200);
            gImage.drawString("双人模式", 220, 300);
            gImage.drawImage(select, 160, y, null);
        } else if (state == 1 || state == 2) {
            gImage.setFont(new Font("仿宋", Font.BOLD, 30));
            gImage.setColor(Color.red);
            gImage.drawString("剩余敌人:" + enemies.size(), 3, 60);
            Draw(gImage);
            count++;
        } else if (state == 5) {
            gImage.drawString("游戏胜利", 220, 200);
        } else if (state == 4) {
            gImage.drawString("游戏失败", 220, 200);
        }
        g.drawImage(offScreemImage, 0, 0, null);//将缓存区绘制好的图形整个绘制到容器的画布中

    }



    public void Draw(Graphics gImage){

        for (Tank tank:playerList) {
            tank.paintSelf(gImage);
        }
        for (Bullet bullet:bullets) {
            bullet.paintSelf(gImage);
        }
        bullets.removeAll(removeList);
        for (Enemy i:enemies) {
            i.paintSelf(gImage);
        }
        for (EnemyBullet enemybullet:enemyBullets) {
            enemybullet.paintSelf(gImage);
        }
        enemyBullets.removeAll(removeList);
        for (Wall wall:walls) {
            wall.paintSelf(gImage);
        }
        for (Base base:bases) {
            base.paintSelf(gImage);
        }
        for (Bomb bomb:bombs) {
            bomb.paintSelf(gImage);
        }
        for (Grass grass:grasses) {
            grass.paintSelf(gImage);
        }
        for (WhiteWall whitewall:whiteWalls) {
            whitewall.paintSelf(gImage);
        }
        for (Love love:loves) {
            love.paintSelf(gImage);
        }
        for (Bombs bom:Bomb) {
            bom.paintSelf(gImage);
        }
    }

    class KeyMonitor extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            int key=e.getKeyCode();
            switch(key){
                case KeyEvent.VK_1:
                    a=1;y=160;
                    break;
                case KeyEvent.VK_2:
                    a=2;y=260;
                    playerList.add(playerTwo);
                    playerTwo.alive=true;
                    break;
                case KeyEvent.VK_ENTER:
                    state=a;
                    playerOne.alive=true;
                    playerList.add(playerOne);
                    bases.add(base1);
                    break;
                default:playerOne.keyPressed(e);playerTwo.keyPressed(e);

            }
    }

    public void keyReleased(KeyEvent e){
            playerOne.keyReleased(e);
            playerTwo.keyReleased(e);
        }
    }

    public void addWall(){
        for (int i = 0; i < 14; i++) {
            walls.add(new Wall(s+"redwall.png",50+i*50,170,this));
        }
        walls.add(new Wall(s+"redwall.png",305,550,this));
        walls.add(new Wall(s+"redwall.png",305,500,this));
        walls.add(new Wall(s+"redwall.png",355,500,this));
        walls.add(new Wall(s+"redwall.png",405,500,this));
        walls.add(new Wall(s+"redwall.png",405,550,this));
        walls.add(new Wall(s+"redwall.png",525,380,this));
        walls.add(new Wall(s+"redwall.png",525,430,this));
        walls.add(new Wall(s+"redwall.png",525,480,this));
        walls.add(new Wall(s+"redwall.png",525,530,this));
        walls.add(new Wall(s+"redwall.png",525,580,this));

        walls.add(new Wall(s+"redwall.png",205,405,this));
        walls.add(new Wall(s+"redwall.png",255,455,this));


    }
    public void addGrass(){
        grasses.add(new Grass(s+"grass.png",0,330,this));
        grasses.add(new Grass(s+"grass.png",50,330,this));
        grasses.add(new Grass(s+"grass.png",100,330,this));

        grasses.add(new Grass(s+"grass.png",260,330,this));
        grasses.add(new Grass(s+"grass.png",310,330,this));
        grasses.add(new Grass(s+"grass.png",360,330,this));

        grasses.add(new Grass(s+"grass.png",620,330,this));
        grasses.add(new Grass(s+"grass.png",670,330,this));
        grasses.add(new Grass(s+"grass.png",720,330,this));
        grasses.add(new Grass(s+"grass.png",770,330,this));

    }
    public void  addwhiteWalls(){

      whiteWalls.add(new WhiteWall(s+"whitewall.png",635,430,this));
      whiteWalls.add(new WhiteWall(s+"whitewall.png",635,480,this));
      whiteWalls.add(new WhiteWall(s+"whitewall.png",635,530,this));
      whiteWalls.add(new WhiteWall(s+"whitewall.png",635,580,this));
    }
    public void addLove(){
        loves.add(new Love(s+"love.png",470,480,this));
        loves.add(new Love(s+"love.png",350,250,this));
    }
    public void addBomb(){
    Bomb.add(new Bombs(s+"bomb.png",680,480,this));
    Bomb.add(new Bombs(s+"bomb.png",455,350,this));
    Bomb.add(new Bombs(s+"bomb.png",5,480,this));
    Bomb.add(new Bombs(s+"bomb.png",350,20,this));

    }
}
